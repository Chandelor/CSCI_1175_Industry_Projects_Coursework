package application;

import static org.junit.Assert.*;

import org.junit.Test;

public class WordManagerTest {

	@Test
	public void testGrabWord() {
		assertEquals(WordManager.grabWord(10, "resources/junitTest.txt"), "HelloWorld");
	}

}
