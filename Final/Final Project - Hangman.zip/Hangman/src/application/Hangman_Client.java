package application;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Hangman_Client {
	
    DataInputStream inputFromServer = null;
    DataOutputStream outputToServer = null;
	int port = 8000;
	
	Hangman_Client() {
	}
	
	Hangman_Client(int port) {
		this.port = port;
	}

	public void client() throws Exception {
        new Thread(() -> {
            try {
                Socket socket = new Socket("localhost", port);
                inputFromServer = new DataInputStream(socket.getInputStream());
                outputToServer = new DataOutputStream(socket.getOutputStream());

                while (true) {
                	
                }

            }
            
            catch (IOException ex) {
            }

        }).start();
		
	}
	
}
