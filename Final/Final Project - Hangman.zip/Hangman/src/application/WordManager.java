package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;


/**
 * <p>This class is used to read words from a txt file and grab one using the provide letter count.</p>
 */
public class WordManager {
	
	/**
	 * <p>Cycles randomly through a txt file of words until one is found with the given letter length.</p>
	 * @param minWordLength (int; used to select a word with the given amount of letters)
	 * @return String (String; the word that was found using this method.)
	 */
	public static String grabWord(int minWordLength, String pathToFile) {
		try {
			Scanner input = new Scanner(new File(pathToFile));
			String word = input.nextLine();
			Path path = Paths.get(pathToFile);
			int wordsInFile = (int) Files.lines(path).count();
			int randomWord = (int) ((Math.random() * (wordsInFile - 0)) + 0);
			
			while (randomWord != 0 && input.hasNextLine()) {
				word = input.nextLine();
				randomWord--;
			}
			
			if (minWordLength < 6) while (word.length() != minWordLength && input.hasNextLine()) word = input.nextLine();
			else while (word.length() < minWordLength && input.hasNextLine()) word = input.nextLine();
			
			return word;
		}
		
		catch (IOException e) {
			e.printStackTrace();
		}
		
		return "null";
	}
	
}
