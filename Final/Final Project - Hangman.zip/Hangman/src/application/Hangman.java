/**
 * @author Chandelor
 * <p>Date: February 6th, 2024</p>
 *
 * <p>
 * This code creates hangman game with 2 seperate modes labeled as classic which is how the game is normally played by everyone, and blitz
 * which is a custom game mode where the player will designate an amount of time to play with and will guess as many words as they can before the timer ends.
 * </p>
 */

package application;

import java.io.FileInputStream;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Hangman extends Application {
	
	WordManager wordManager = new WordManager();
	BorderPane borderPane = new BorderPane();
	HBox topDisplay = new HBox();
	HBox letters = new HBox();
	VBox display = new VBox();
	
	Group hangman = new Group();
	
	TextField tf = new TextField();
	
	int time = 0;
	int failCount = 0;
	int successCount = 0;
	String word = "";
	String pathToFile = "resources/words.txt";
	
	Label title = new Label("Hangman Game");
	Label difficulty = new Label("Difficulty");
//	Label mode = new Label("Game Mode");
//	Label connection = new Label("Create/Join Lobby");
	Label getTime = new Label("Duration(seconds): ");
	Label scoreDisplay = new Label("Score: " + successCount);
	
	MenuButton menuButton = new MenuButton("Options");
	MenuItem miMainMenu = new MenuItem("Main Menu");
	MenuItem miExit = new MenuItem("Quit Game");
	
	Button submitTime = new Button("Submit");
	Button easy = new Button("Easy (4 letters)");
	Button normal = new Button("Normal (5 letters)");
	Button hard = new Button("Hard (6+ letters)");
//	Button onePlayer = new Button("One Player");
	Button classic = new Button("Classic");
	Button blitz = new Button("Blitz");
//	Button twoPlayer = new Button("Two Player");
//	Button hostGame = new Button("Host Game");
//	Button joinGame = new Button("Join Game");
//	Button pvp = new Button("Classic PvP");
//	Button blitzpvp = new Button("Blitz PvP");
	Button mainMenu = new Button("Main Menu");
	Button exit = new Button("Exit");
	Button freebie = new Button("Freebie");
	
	/**
	 * <p>This method starts the program</p>
	 * @param primaryStage (Stage; Used to store all of the nodes and panes that are displayed to the user.)
	 * @throws Exception (Throws an exception if the image file can't be found.)
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		Image image = new Image(new FileInputStream("resources/Hangman.gif"));
		ImageView imageView = new ImageView(image);
		
		mainMenuDisplay(imageView);
		mainMenu(imageView);
		
		Scene scene = new Scene(borderPane, 800, 550);
		primaryStage.setResizable(false);
		primaryStage.setTitle("Hangman"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}
	
	/**
	 * <p>This method declares what the majority of the buttons do in this program</p>
	 * @param imageView (ImageView; this is the image that is displayed on the main menu.)
	 */
	public void buttonAction(ImageView imageView) {
//		onePlayer.setOnAction(e -> {
//			display.getChildren().clear();
//			display.getChildren().addAll(title, imageView, classic, blitz, exit);
			
			classic.setOnAction(c -> difficultySelect(imageView, "solo"));
			blitz.setOnAction(b -> difficultySelect(imageView, "soloBlitz"));
			mainMenu.setOnAction(n -> mainMenu(imageView));
//		});
		
//		twoPlayer.setOnAction(e -> {
//			display.getChildren().clear();
//			display.getChildren().addAll(connection, hostGame, joinGame, mainMenu);
//			
//			hostGame.setOnAction(h -> {
//				display.getChildren().clear();
//				display.getChildren().addAll(mode, pvp, mainMenu);
//				
//				pvp.setOnAction(c -> difficultySelect(imageView, "host"));
//				blitzpvp.setOnAction(b -> difficultySelect(imageView, "host"));
//				mainMenu.setOnAction(n -> mainMenu(imageView));
//				
//			});
//			
//			joinGame.setOnAction(j -> {
//				display.getChildren().clear();
//				display.getChildren().addAll(mode, pvp, mainMenu);
//				
//				pvp.setOnAction(c -> difficultySelect(imageView, "join"));
//				blitzpvp.setOnAction(b -> difficultySelect(imageView, "join"));
//				mainMenu.setOnAction(n -> mainMenu(imageView));
//			});
//			
//		});
		
		miMainMenu.setOnAction(e -> mainMenu(imageView));
		miExit.setOnAction(e -> Platform.exit());
		exit.setOnAction(e -> Platform.exit());
	}
	
	/**
	 * <p>Clears the display and game progress then resets the user to the first displayed menu.</p>
	 * @param imageView (ImageView; this is the image that is displayed on the main menu.)
	 */
	public void mainMenu(ImageView imageView) {
			display.getChildren().clear();
			topDisplay.getChildren().clear();
			display.getChildren().addAll(title, imageView, classic, blitz, exit);
//			display.getChildren().addAll(title, imageView, onePlayer, twoPlayer, exit);
			failCount = 0;
			successCount = 0;
			buttonAction(imageView);
	}

	
/**
	 * <p>This method formats almost everything that is displayed in the program so that it is the correct size, font, and location.</p>
	 * @param imageView (ImageView; this is the image that is displayed on the main menu.)
	 */
	@SuppressWarnings("static-access")
	public void mainMenuDisplay(ImageView imageView) {
		
		int buttonHeight = 20;
		int buttonWidth = 150;
		
		submitTime.setPrefHeight(buttonHeight);
		easy.setPrefHeight(buttonHeight);
		normal.setPrefHeight(buttonHeight);
		hard.setPrefHeight(buttonHeight);
//		onePlayer.setPrefHeight(buttonHeight);
		classic.setPrefHeight(buttonHeight);
		blitz.setPrefHeight(buttonHeight);
//		twoPlayer.setPrefHeight(buttonHeight);
//		hostGame.setPrefHeight(buttonHeight);
//		joinGame.setPrefHeight(buttonHeight);
//		pvp.setPrefHeight(buttonHeight);
//		blitzpvp.setPrefHeight(buttonHeight);
		mainMenu.setPrefHeight(buttonHeight);
		exit.setPrefHeight(buttonHeight);
		
		submitTime.setPrefWidth(buttonWidth);
		easy.setPrefWidth(buttonWidth);
		normal.setPrefWidth(buttonWidth);
		hard.setPrefWidth(buttonWidth);
//		onePlayer.setPrefWidth(buttonWidth);
		classic.setPrefWidth(buttonWidth);
		blitz.setPrefWidth(buttonWidth);
//		twoPlayer.setPrefWidth(buttonWidth);
//		hostGame.setPrefWidth(buttonWidth);
//		joinGame.setPrefWidth(buttonWidth);
//		pvp.setPrefWidth(buttonWidth);
//		blitzpvp.setPrefWidth(buttonWidth);
		mainMenu.setPrefWidth(buttonWidth);
		exit.setPrefWidth(buttonWidth);
		
		submitTime.setStyle("-fx-font-size:14");
		easy.setStyle("-fx-font-size:14");
		normal.setStyle("-fx-font-size:14");
		hard.setStyle("-fx-font-size:14");
//		onePlayer.setStyle("-fx-font-size:14");
		classic.setStyle("-fx-font-size:14");
		blitz.setStyle("-fx-font-size:14");
//		twoPlayer.setStyle("-fx-font-size:14");
//		hostGame.setStyle("-fx-font-size:14");
//		joinGame.setStyle("-fx-font-size:14");
//		pvp.setStyle("-fx-font-size:14");
//		blitzpvp.setStyle("-fx-font-size:14");
		mainMenu.setStyle("-fx-font-size:14");
		exit.setStyle("-fx-font-size:14");
		
		imageView.setFitHeight(300);
		imageView.setFitWidth(250);
		imageView.setPreserveRatio(true); 
		
		display.setAlignment(Pos.CENTER);
		display.setSpacing(15);
		display.setMargin(imageView, new Insets(20));
		display.setMargin(mainMenu, new Insets(30));
		display.setMargin(exit, new Insets(30));
		
		title.setUnderline(true);
		difficulty.setUnderline(true);
//		mode.setUnderline(true);
//		connection.setUnderline(true);
		
		int fontSize = 50;
		title.setFont(new Font(fontSize));
		difficulty.setFont(new Font(fontSize));
//		mode.setFont(new Font(fontSize));
//		connection.setFont(new Font(fontSize));
		
		menuButton.getItems().addAll(miMainMenu, miExit);
		
		borderPane.setStyle("-fx-background-color: grey;");
		borderPane.setCenter(display);
	}
	

	
	/**
	 * <p>Sets up functions for each difficulty button and sends the letter count based on that difficulty to decide how many letters the word will be.</p>
	 * @param imageView (ImageView; this is the image that is displayed on the main menu.)
	 * @param gameType (String; is used to decide if the game will run classic or blitz mode.)
	 */
	public void difficultySelect(ImageView imageView, String gameType) {
		
		if (gameType == "solo") {
			display.getChildren().clear();
			display.getChildren().addAll(difficulty, easy, normal, hard, mainMenu);
			
			easy.setOnAction(d1 -> runGame(4, gameType));
			normal.setOnAction(d2 -> runGame(5, gameType));
			hard.setOnAction(d3 -> runGame(6, gameType));
			mainMenu.setOnAction(n -> mainMenu(imageView));
		}
		
		else if (gameType == "soloBlitz") getUserTime(imageView, gameType);
			
		
//		else if (gameType == "host") {
//			Hangman_Server host = new Hangman_Server(8000);
//			try {
//				host.server();
//				easy.setOnAction(d1 -> runGame(4, gameType));
//				normal.setOnAction(d2 -> runGame(5, gameType));
//				hard.setOnAction(d3 -> runGame(6, gameType));
//				mainMenu.setOnAction(n -> mainMenu(imageView));
//			}
//			
//			catch (Exception e) {
//				e.printStackTrace();
//			}
//			
//		}
//		
//		else if (gameType == "join") {
//			Hangman_Client join = new Hangman_Client(8000);
//			try {
//				join.client();
//				easy.setOnAction(d1 -> runGame(4, gameType));
//				normal.setOnAction(d2 -> runGame(5, gameType));
//				hard.setOnAction(d3 -> runGame(6, gameType));
//				mainMenu.setOnAction(n -> mainMenu(imageView));
//			}
//			
//			catch (Exception e) {
//				e.printStackTrace();
//			}
//
//		}
		
	}
	
	/**
	 * <p>If the button is used in the game it will select one of the letters for the missing word and display it without adding to the fail count.</p>
	 * @param line1 (HBox; this line is used to display the first 13 letters of the alphabet to the user.
	 * @param line2 (HBox; this line is used to display the last 13 letters of the alphabet to the user.
	 * 
	 */
	public void freebie(HBox line1, HBox line2) {
		
		int charAt = (int) ((Math.random() * (word.length() - 0)) + 0);
		char randomChara = word.charAt(charAt);
		while (true) {
			charAt = (int) ((Math.random() * (word.length() - 0)) + 0);
			randomChara = word.charAt(charAt);
			
			if (((Label)letters.getChildren().get(charAt)).getText() == "_")  break;
		}
		
		for (int n = 0; n < line1.getChildren().size(); n++) {
			char temp = ((Label) (line1.getChildren().get(n))).getText().charAt(0);
			if (temp == randomChara) {
				line1.getChildren().remove(n);
				characterCheck(String.valueOf(randomChara));
			}
			
		}
		
		for (int n = 0; n < line2.getChildren().size(); n++) {
			char temp = ((Label) (line2.getChildren().get(n))).getText().charAt(0);
			if (temp == randomChara) {
				line2.getChildren().remove(n);
				characterCheck(String.valueOf(randomChara));
			}
			
		}
		
	}
	
	/**
	 * <p>Generates a new word that is used in the game.</p>
	 * @param letterCount (int; used to decide how many letters the word used in the game will have.)
	 */
	@SuppressWarnings("static-access")
	public void newWord(int letterCount) {
		word = wordManager.grabWord(letterCount, pathToFile).toUpperCase();
		letters.getChildren().clear();
		for (int n = 0; n != word.length(); n++) letters.getChildren().add(new Label ("_"));
	}
	
	/**
	 * <p>Creates the display to show clickable characters that are used to guess the hidden word.</p>
	 * @param gameType (String; is used to decide if the game will run classic or blitz mode.)
	 */
	public void availableCharacters(String gameType) {
		HBox line1 = new HBox(13);
		HBox line2 = new HBox(13);
		VBox allLines = new VBox(2);
		
		line1.getChildren().clear();
		line2.getChildren().clear();
		allLines.getChildren().clear();
		line1.setAlignment(Pos.CENTER);
		line2.setAlignment(Pos.CENTER);
		
		Label[] characters = new Label[26];
		for(int i = 0; i < 26; i++){
			char temp = (char) (i + 65);
			characters[i] = new Label();
			characters[i].setUnderline(true);
			characters[i].setText(String.valueOf(temp));
			characters[i].setFont(new Font(20));
			
			if (i <= 12) line1.getChildren().add(characters[i]);
			else if (i > 12) line2.getChildren().add(characters[i]);
		}
		
		allLines.getChildren().addAll(line1, line2);
		display.getChildren().addAll(allLines);
		
		characterClicked(characters, line1, line2, gameType);
	}
	
	/**
	 * <p>This method will detect any clicks on the characters displayed to the user and will then remove those characters after which the code will 
	 * will call a method to check if the word contains the guess letter.</p>
	 * @param characters (Label[]; this array contains each character that the user can click on.)
	 * @param line1 (HBox; this line is used to display the first 13 letters of the alphabet to the user.
	 * @param line2 (HBox; this line is used to display the last 13 letters of the alphabet to the user.
	 * @param gameType (String; is used to decide if the game will run classic or blitz mode.)
	 */
	public void characterClicked(Label[] characters, HBox line1, HBox line2, String gameType) {
		freebie.setOnAction(e -> {
			freebie(line1, line2);
			winCheck(gameType);
		});
		
		characters[0].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[0]);
			characterCheck(characters[0].getText());
			winCheck(gameType);
		});
		characters[1].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[1]);
			characterCheck(characters[1].getText());
			winCheck(gameType);
		});
		characters[2].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[2]);
			characterCheck(characters[2].getText());
			winCheck(gameType);
		});
		characters[3].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[3]);
			characterCheck(characters[3].getText());
			winCheck(gameType);
		});
		characters[4].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[4]);
			characterCheck(characters[4].getText());
			winCheck(gameType);
		});
		characters[5].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[5]);
			characterCheck(characters[5].getText());
			winCheck(gameType);
		});
		characters[6].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[6]);
			characterCheck(characters[6].getText());
			winCheck(gameType);
		});
		characters[7].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[7]);
			characterCheck(characters[7].getText());
			winCheck(gameType);
		});
		characters[8].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[8]);
			characterCheck(characters[8].getText());
			winCheck(gameType);
		});
		characters[9].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[9]);
			characterCheck(characters[9].getText());
			winCheck(gameType);
		});
		characters[10].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[10]);
			characterCheck(characters[10].getText());
			winCheck(gameType);
		});
		characters[11].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[11]);
			characterCheck(characters[11].getText());
			winCheck(gameType);
		});
		characters[12].setOnMouseClicked(e -> {
			line1.getChildren().remove(characters[12]);
			characterCheck(characters[12].getText());
			winCheck(gameType);
		});
		characters[13].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[13]);
			characterCheck(characters[13].getText());
			winCheck(gameType);
		});
		characters[14].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[14]);
			characterCheck(characters[14].getText());
			winCheck(gameType);
		});
		characters[15].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[15]);
			characterCheck(characters[15].getText());
			winCheck(gameType);
		});
		characters[16].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[16]);
			characterCheck(characters[16].getText());
			winCheck(gameType);
		});
		characters[17].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[17]);
			characterCheck(characters[17].getText());
			winCheck(gameType);
		});
		characters[18].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[18]);
			characterCheck(characters[18].getText());
			winCheck(gameType);
		});
		characters[19].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[19]);
			characterCheck(characters[19].getText());
			winCheck(gameType);
		});
		characters[20].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[20]);
			characterCheck(characters[20].getText());
			winCheck(gameType);
		});
		characters[21].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[21]);
			characterCheck(characters[21].getText());
			winCheck(gameType);
		});
		characters[22].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[22]);
			characterCheck(characters[22].getText());
			winCheck(gameType);
		});
		characters[23].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[23]);
			characterCheck(characters[23].getText());
			winCheck(gameType);
		});
		characters[24].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[24]);
			characterCheck(characters[24].getText());
			winCheck(gameType);
		});
		characters[25].setOnMouseClicked(e -> {
			line2.getChildren().remove(characters[25]);
			characterCheck(characters[25].getText());
			winCheck(gameType);
		});
		
	}
	
	/**
	 * <p>Checks if the recieved character is a part of the word.</p>
	 * @param character (String; the character being checked.)
	 */
	public void characterCheck(String character) {
		boolean matched = false;
		for (int i = 0; i < word.length(); i++) {
			char tempChar = character.charAt(0);
			if (word.charAt(i) == tempChar) {
				Label tempLabel = new Label(character);
				tempLabel.setUnderline(true);
				tempLabel.setFont(new Font(40));
				letters.getChildren().set(i, tempLabel);
				successCount++;
				scoreDisplay.setText("Score: " + (successCount * 100));
				matched = true;
			}
			
		}
			
		if (matched == false) {
			failCount++;
			displayHangman();
		}
			
	}
	
	/**
	 * <p>Displays the pole that the hanged man would hang from.</p>
	 */
	public void displayHangmanBase() {
		Line base = new Line(25, 25, 25, 200);
        Line pole = new Line(10, 200, 175, 200);
        Line overhang = new Line(25, 25, 125, 25);
        Line rope = new Line(125, 75, 125, 25);
        
        hangman.getChildren().clear();
		hangman.getChildren().addAll(base, pole, overhang, rope);
		
		base.setStrokeWidth(5);
		pole.setStrokeWidth(5);
		overhang.setStrokeWidth(5);
		
		display.getChildren().addAll(hangman);
	}
	
	/**
	 * <p>Displays the hanged man</p>
	 */
	public void displayHangman() {
        Ellipse head = new Ellipse(125, 75, 10, 11);
        Line body = new Line(125, 135, 125, 86);
        Line leftArm = new Line(100, 115, 125, 86);
        Line rightArm = new Line(150, 115, 125, 86);
        Line leftLeg = new Line(100, 165, 125, 135);
        Line rightLeg = new Line(150, 165, 125, 135);
		
        switch(failCount) {
        case 1: hangman.getChildren().add(head); break;
        case 2: hangman.getChildren().add(body); break;
        case 3: hangman.getChildren().add(leftArm); break;
        case 4: hangman.getChildren().add(rightArm); break;
        case 5: hangman.getChildren().add(leftLeg); break;
        case 6: hangman.getChildren().add(rightLeg); break;
        case 7: gameOver();
        }
        
		head.setFill(Color.GREY);
		head.setStroke(Color.BLACK);
	}
	
	/**
	 * <p>Creates a timeline to countdown the entered seconds when playing the blitz mode.</p>
	 */
	@SuppressWarnings("static-access")
	public void timer() {
		time = Integer.valueOf(tf.getText());
		VBox scoreAndTimerDisplay = new VBox(2);
		Label timerDisplay = new Label("Timer: " + time);
		
		int fontSize = 20;
		scoreDisplay.setFont(new Font(fontSize));
		timerDisplay.setFont(new Font(fontSize));
		
		long startSeconds = System.nanoTime();
		EventHandler<ActionEvent> eventHandler = e -> {
			long elapsedSeconds = (System.nanoTime() - startSeconds) / 1000000000;
			timerDisplay.setText("Timer: " + (time - elapsedSeconds));
		};

		Timeline animation = new Timeline(new KeyFrame(Duration.millis(1000), eventHandler));
		animation.setCycleCount(time);
		animation.play();
		animation.setOnFinished(e -> {
			display.getChildren().clear();
			topDisplay.getChildren().clear();
			scoreDisplay.setFont(new Font(30));
			display.setMargin(exit, new Insets(150, 0, 0, 0));
			display.getChildren().addAll(scoreDisplay, exit);
		});
		
		scoreAndTimerDisplay.getChildren().addAll(timerDisplay, scoreDisplay);
		
		topDisplay.setMargin(scoreAndTimerDisplay, new Insets(0, 0, 0, 500));
		topDisplay.getChildren().add(scoreAndTimerDisplay);
	}
	
	/**
	 * <p>Displays a text field asking the user for how many seconds they want to play the blitz mode for along with a submit button.</p>
	 * @param imageView (ImageView; this is the image that is displayed on the main menu.)
	 * @param gameType (String; is used to decide if the game will run classic or blitz mode.)
	 */
	public void getUserTime(ImageView imageView, String gameType) {
		HBox hbox = new HBox();
		VBox vbox = new VBox();
		tf.setPrefSize(50, 20);
		getTime.setFont(new Font(20));
		hbox.getChildren().addAll(getTime, tf);
		vbox.getChildren().addAll(hbox, submitTime);
		
		vbox.setSpacing(15);
		hbox.setAlignment(Pos.CENTER);
		vbox.setAlignment(Pos.CENTER);
		
		display.getChildren().clear();
		display.getChildren().addAll(title, imageView, vbox, mainMenu);
		submitTime.setOnAction(e -> {
			try {
				int x = Integer.parseInt(tf.getText());
				if (tf.getText() != "") runGame(4, gameType);
			}
			
			catch(NumberFormatException ex) {
				System.out.println("input is not an int value"); 
			} 
			
		});
	}
	
	/**
	 * <p>Used to start the game.</p>
	 * @param letterCount (int; used to decide how many letters the word used in the game will have.)
	 * @param gameType (String; is used to decide if the game will run classic or blitz mode.)
	 */
	public void runGame(int letterCount, String gameType) {
		newWord(letterCount);
		letters.setAlignment(Pos.CENTER);
		letters.setStyle("-fx-font-size:60");
		letters.setSpacing(17);
		
		topDisplay.getChildren().clear();
		topDisplay.getChildren().addAll(menuButton, freebie);
		borderPane.setTop(topDisplay);
		
		if (gameType == "soloBlitz") timer();
		
		display.getChildren().clear();
		displayHangmanBase();
		display.getChildren().add(letters);
		availableCharacters(gameType);
	}
	
	/**
	 * <p>Checks if the word has been guessed in classic mode, and displays a new word if in blitz mode.</p>
	 * @param gameType (String; is used to decide if the game will run classic or blitz mode.)
	 */
	public void winCheck(String gameType) {
		String tempString = "";
		for (int n = 0; n < letters.getChildren().size(); n++) {
			tempString = tempString + ((Label) letters.getChildren().get(n)).getText();
		}
		
		if (!tempString.contains("_")) {
			if (gameType != "soloBlitz") winGame();
			else {
				display.getChildren().clear();
				failCount = 0;
				displayHangmanBase();
				display.getChildren().add(letters);
				newWord(4);
				availableCharacters(gameType);
			}
			
		}
			
	}
	
	/**
	 * <p>Ends the game and displays "Winner!".</p>
	 */
	public void winGame() {
		Label winner = new Label("Winner!");
		winner.setFont(new Font(145));
		topDisplay.getChildren().clear();
		display.getChildren().set(0, winner);
		display.getChildren().set(2, exit);
	}
	
	/**
	 * <p>Ends the game and displays "Game Over".</p>
	 */
	public void gameOver() {
		Label gameOver = new Label("Game Over");
		gameOver.setFont(new Font(145));
		topDisplay.getChildren().clear();
		display.getChildren().set(0, gameOver);
		display.getChildren().set(2, exit);
	}
	
	public static void main(String[] args) {
		launch(args);
	}

}
