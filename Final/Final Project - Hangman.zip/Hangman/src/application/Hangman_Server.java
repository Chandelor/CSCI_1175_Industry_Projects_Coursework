package application;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;

public class Hangman_Server {

	DataInputStream inputFromClient = null;
	DataOutputStream outputToClient = null;
	int port = 8000;
	
	Hangman_Server() {
	}
	
	Hangman_Server(int port) {
		this.port = port;
	}
	
	public void server() throws Exception {
		new Thread(() -> {
			try {
				ServerSocket serverSocket = new ServerSocket(port);
				Socket socket = serverSocket.accept();
				Hangman gameServer = new Hangman();
				
			}
			
			catch (IOException e) {
				System.out.println("Port " + port + " is in use.");
			}
		
		}).start();
		
	}
	
}
