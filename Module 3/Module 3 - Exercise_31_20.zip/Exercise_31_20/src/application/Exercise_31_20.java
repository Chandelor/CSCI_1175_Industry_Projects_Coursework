/**
 * @author Chandelor
 * Date: 1/3/24
 */
package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Exercise_31_20 extends Application {

	@Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        TabPane tabPane = new TabPane();
        Tab tab1 = new Tab("Line");
        StackPane pane1 = new StackPane();
        pane1.getChildren().add(new Line(10, 10, 80, 80));
        tab1.setContent(pane1);
        Tab tab2 = new Tab("Rectangle");
        tab2.setContent(new Rectangle(10, 10, 200, 200));
        Tab tab3 = new Tab("Circle");
        tab3.setContent(new Circle(50, 50, 20));
        Tab tab4 = new Tab("Ellipse");
        tab4.setContent(new Ellipse(10, 10, 100, 80));
        tabPane.getTabs().addAll(tab1, tab2, tab3, tab4);
        
        HBox hbox = new HBox(10);
        VBox vbox = new VBox();
        
        ToggleGroup tGroup = new ToggleGroup();
        RadioButton top = new RadioButton("Top");
        RadioButton bottom = new RadioButton("Bottom");
        RadioButton left = new RadioButton("Left");
        RadioButton right = new RadioButton("Right");

        top.setToggleGroup(tGroup);
        bottom.setToggleGroup(tGroup);
        left.setToggleGroup(tGroup);
        right.setToggleGroup(tGroup);
        
        hbox.getChildren().addAll(top, bottom, left, right);
        hbox.setAlignment(Pos.CENTER);
        hbox.setPadding(new Insets(10));

        vbox.getChildren().addAll(tabPane, hbox);
        
        top.setOnAction(e -> tabPane.setSide(Side.TOP));
        bottom.setOnAction(e -> tabPane.setSide(Side.BOTTOM));
        left.setOnAction(e -> tabPane.setSide(Side.LEFT));
        right.setOnAction(e -> tabPane.setSide(Side.RIGHT));

        Scene scene = new Scene(vbox, 300, 250);
        primaryStage.setTitle("DisplayFigure");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

