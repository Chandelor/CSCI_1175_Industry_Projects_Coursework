/**
 * @author Chandelor
 * Date: 1/3/24
 */
package application;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Exercise_31_17 extends Application {
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		FlowPane pane = new FlowPane();
		HBox hbox = new HBox();
		VBox vbox1 = new VBox(4);
		VBox vbox2 = new VBox(5);
		Button cButton = new Button("Calculate");
		MenuItem calculate = new MenuItem("Calculate");
		MenuItem exit = new MenuItem("Exit");
		MenuButton mButton = new MenuButton("Operation");
		ToolBar toolbar = new ToolBar(mButton);
		
		mButton.getItems().add(calculate);
		mButton.getItems().add(exit);
		
		Label label1 = new Label("Investment Amount: ");
		Label label2 = new Label("Number of Years: ");
		Label label3 = new Label("Annual Interest Rate: ");
		Label label4 = new Label("Future Value: ");
		TextField tf1 = new TextField();
		TextField tf2 = new TextField();
		TextField tf3 = new TextField();
		TextField tf4 = new TextField();
		
		int tfSpacing = 200;
		tf1.setMinWidth(tfSpacing);
		tf2.setMinWidth(tfSpacing);
		tf3.setMinWidth(tfSpacing);
		tf4.setMinWidth(tfSpacing);
		tf1.setAlignment(Pos.CENTER_RIGHT);
		tf2.setAlignment(Pos.CENTER_RIGHT);
		tf3.setAlignment(Pos.CENTER_RIGHT);
		tf4.setAlignment(Pos.CENTER_RIGHT);
		tf4.setEditable(false);
		
		label1.setFont(new Font("Arial", 14));
		label2.setFont(new Font("Arial", 14));
		label3.setFont(new Font("Arial", 14));
		label4.setFont(new Font("Arial", 14));
		
		toolbar.setMinWidth(400);
		vbox1.setPadding(new Insets(11));
		vbox1.setSpacing(15);
		vbox2.setAlignment(Pos.BASELINE_RIGHT);
		hbox.setPadding(new Insets(5));
		hbox.setSpacing(20);
		
		vbox1.getChildren().addAll(label1, label2, label3, label4);
		vbox2.getChildren().addAll(tf1, tf2, tf3, tf4, cButton);
		hbox.getChildren().addAll(vbox1, vbox2);
		pane.getChildren().add(toolbar);
		pane.getChildren().add(hbox);
		
	    // Create a scene and place it in the stage
	    Scene scene = new Scene(pane, 400, 200);
	    primaryStage.setTitle("Exercise_31_17"); // Set the stage title
	    primaryStage.setScene(scene); // Place the scene in the stage
	    primaryStage.show(); // Display the 
	    
	    cButton.setOnAction(e -> {
	    	tf4.clear();
	    	tf4.appendText(String.format("%.2f", findFutureValue(tf1, tf2, tf3)));
	    });
	    
	    calculate.setOnAction(e -> {
	    	tf4.clear();
	    	tf4.appendText(String.format("%.2f", findFutureValue(tf1, tf2, tf3)));
	    });
	    
	    exit.setOnAction(e -> Platform.exit());
	}
	
	public double findFutureValue(TextField tf1, TextField tf2, TextField tf3) {
		try {
	    	double investmentAmount = Double.parseDouble(tf1.getText());
	    	double numberOfYears = Double.parseDouble(tf2.getText());
	    	double annualInterestDecimal = Double.parseDouble(tf3.getText()) / 100;
	    	double monthlyInterest = annualInterestDecimal / 12;
	    	return investmentAmount * (1 + (monthlyInterest * (numberOfYears * 12)));
		}
		
		catch (Exception e) {
			System.out.println(e);
		}
		
		return 0;
	}

	public static void main(String[] args) {
		launch(args);
	}

}
