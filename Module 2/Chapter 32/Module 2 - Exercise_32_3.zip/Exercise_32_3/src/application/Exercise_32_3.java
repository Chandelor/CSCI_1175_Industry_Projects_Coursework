/**
 * @author Chandelor
 * Date: 12/20/23
 */

package application;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Exercise_32_3 extends Application{

	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
		// Create a pane
		StackPane pane = new StackPane();
	
		// Add an image view and add it to pane
		ImageView imageView = new ImageView("image/us.gif");
		pane.getChildren().add(imageView);
		pane.setAlignment(Pos.BOTTOM_CENTER);
		pane.setLayoutY(pane.getLayoutY() + 80);
		
        new Thread(new Runnable() {

			@Override
			public void run() {
	            try {
	                while (true) {
	                	pane.setLayoutY(pane.getLayoutY() - 1);
	                    Thread.sleep(30);
	                }
	                
	            }
	            
	            catch (InterruptedException ex) {
	            }
			}
        
        }).start();
        
		// Create a scene and place it in the stage
		Scene scene = new Scene(pane, 250, 200); 
		primaryStage.setTitle("FlagRisingAnimation"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}
		
	public static void main(String[] args) {
		Application.launch(args);
	}
	
}
